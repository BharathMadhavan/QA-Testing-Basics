# API Test Report

API Tested: Login API
Method: POST
URL: /api/login

Test Scenarios:
1. Valid login → 200 OK
2. Invalid login → 401 Unauthorized
3. Empty fields → 400 Bad Request
