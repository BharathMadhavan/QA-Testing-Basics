# Boundary Value Analysis

Example:
Inputs: 1–100
Test at boundaries: 0, 1, 2, 99, 100, 101
