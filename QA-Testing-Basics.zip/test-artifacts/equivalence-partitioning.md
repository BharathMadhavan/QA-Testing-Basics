# Equivalence Partitioning

Example:
Valid range: 18–60
Invalid ranges: <18 and >60
