# Test Plan

Project: QA Testing Basics
Prepared By: Bharath M
Scope: Functional testing of web login module

Testing Types:
- Functional testing
- Regression testing
- Smoke testing
- Compatibility testing

Entry Criteria:
- Requirements finalized

Exit Criteria:
- All critical test cases executed
