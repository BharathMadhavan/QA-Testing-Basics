# Bug Report Sample

Bug ID: BUG_001
Title: Login button not working
Severity: High
Priority: P1
Environment: Chrome 128, Windows 10
Steps to Reproduce:
1. Open login page
2. Enter username and password
3. Click Login button
Actual Result: Nothing happens
Expected Result: User should be logged in
